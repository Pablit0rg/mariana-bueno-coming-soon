import { Inter } from "next/font/google";

// Fonte Padrão (Limpa, Moderna e Sem Serifa)
export const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});
